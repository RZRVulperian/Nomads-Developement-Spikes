# CPRP Spikes v1.1.0 (Standalone)

Adds server features:
- /spikes_clearall (ACE-protected)
- Optional ACE gating for deploy/pickup (police-only style)
- Auto-cleanup when a player disconnects

## Install
1. Unzip as resources/cprp_spikes/
2. In server.cfg:
   ensure cprp_spikes

## Permissions (optional but recommended)
- Gate usage to police (or any group):
  add_ace group.police cprp_spikes.use allow
- Allow admins to clear all:
  add_ace group.admin cprp_spikes.admin allow
- Put players in groups per your ACL setup:
  add_principal identifier.steam:110000112345678 group.police

Then set in config.lua:
  Config.RequireAceUse = true

## Commands
- Client keybinds (rebind in Settings -> Key Bindings -> FiveM):
  F6=1 strip, F7=2, F8=3, F9=pickup (defaults; rebindable)
- Chat aliases: /spike1 /spike2 /spike3 /spikepickup
- Server admin: /spikes_clearall  (requires ACE cprp_spikes.admin)

## Notes
- Entities are registered with the server for cleanup.
- On player drop, their spikes are removed.
- Still 100 percent standalone: no ESX/QBCore.
