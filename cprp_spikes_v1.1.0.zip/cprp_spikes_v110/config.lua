-- cprp_spikes / config.lua

Config = {}

-- Model name as a string. The code will hash it at runtime.
Config.SpikeModel = "p_ld_stinger_s"

-- Placement
Config.ForwardOffset = 2.5
Config.SideSpacing = 3.5
Config.MaxActiveSpikesPerPlayer = 6

-- Detection
Config.VehicleScanIntervalMs = 150
Config.VehicleAffectRadius = 6.0
Config.MinSpeedToPop = 4.5
Config.RehitCooldownMs = 5000

-- Key defaults (players can rebind)
Config.KeyDefaults = { spawn1 = "F6", spawn2 = "F7", spawn3 = "F8", pickup = "F9" }

-- Permission model
-- Set RequireAceUse to true to require ACE "cprp_spikes.use" to deploy/pickup.
Config.RequireAceUse = false
Config.AceUse = "cprp_spikes.use"      -- grant with: add_ace group.police cprp_spikes.use allow
Config.AceAdmin = "cprp_spikes.admin"  -- grant with: add_ace group.admin cprp_spikes.admin allow

-- Debug
Config.Debug = false
