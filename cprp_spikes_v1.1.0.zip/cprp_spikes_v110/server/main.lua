-- cprp_spikes / server/main.lua
-- Server registry, ACE gating, clearall, auto-cleanup on drop.

local spikesByPlayer = {} -- [src] = { netIds... }

local function addSpike(src, netId)
    if not spikesByPlayer[src] then spikesByPlayer[src] = {} end
    table.insert(spikesByPlayer[src], netId)
end

local function removeSpike(src, netId)
    local list = spikesByPlayer[src]
    if not list then return end
    for i = #list, 1, -1 do
        if list[i] == netId then
            table.remove(list, i)
        end
    end
    if #list == 0 then spikesByPlayer[src] = nil end
end

local function deleteNetEntity(netId)
    if not netId then return end
    local ent = NetworkGetEntityFromNetworkId(netId)
    if ent and ent ~= 0 then
        if DoesEntityExist(ent) then
            DeleteEntity(ent)
        end
    end
end

RegisterNetEvent("cprp_spikes:register")
AddEventHandler("cprp_spikes:register", function(netId)
    local src = source
    addSpike(src, netId)
end)

RegisterNetEvent("cprp_spikes:unregister")
AddEventHandler("cprp_spikes:unregister", function(netId)
    local src = source
    removeSpike(src, netId)
end)

-- Authorization query from client
RegisterNetEvent("cprp_spikes:reqAllowed")
AddEventHandler("cprp_spikes:reqAllowed", function()
    local src = source
    local allowed = true
    if Config.RequireAceUse then
        allowed = IsPlayerAceAllowed(src, Config.AceUse)
    end
    TriggerClientEvent("cprp_spikes:resAllowed", src, allowed)
end)

-- Cleanup when player drops
AddEventHandler("playerDropped", function(reason)
    local src = source
    local list = spikesByPlayer[src]
    if list then
        for _, netId in ipairs(list) do
            deleteNetEntity(netId)
        end
        spikesByPlayer[src] = nil
    end
end)

-- Admin command: /spikes_clearall
RegisterCommand("spikes_clearall", function(src, args, raw)
    if src == 0 then
        -- console always allowed
    else
        if not IsPlayerAceAllowed(src, Config.AceAdmin) then
            TriggerClientEvent("cprp_spikes:notify", src, "^1Spikes", "You are not allowed to use /spikes_clearall.")
            return
        end
    end

    local count = 0
    for psrc, list in pairs(spikesByPlayer) do
        for _, netId in ipairs(list) do
            deleteNetEntity(netId)
            count = count + 1
        end
        spikesByPlayer[psrc] = nil
    end

    if src == 0 then
        print(string.format("[cprp_spikes] Cleared %d spike entities", count))
    else
        TriggerClientEvent("cprp_spikes:notify", src, "^2Spikes", "Cleared " .. tostring(count) .. " spike entities.")
    end
end, false)

-- Safety: cleanup on resource stop
AddEventHandler("onResourceStop", function(res)
    if res ~= GetCurrentResourceName() then return end
    for _, list in pairs(spikesByPlayer) do
        for _, netId in ipairs(list) do
            deleteNetEntity(netId)
        end
    end
    spikesByPlayer = {}
end)
