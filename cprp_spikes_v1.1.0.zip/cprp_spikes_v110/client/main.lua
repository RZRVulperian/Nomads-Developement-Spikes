-- cprp_spikes / client/main.lua
-- Client: deploy 1/2/3, pickup, registration with server, ACE check via server ping.

print("^2[cprp_spikes]^7 client loaded")

local spawnedSpikes = {}      -- { {ent=entity, net=netId}, ... }
local spikedRecently = {}     -- [veh] = lastTimeMs
local allowCache = nil
local waitingAuth = false

local function dbg(msg)
    if Config and Config.Debug then
        print(string.format("[cprp_spikes] %s", tostring(msg)))
    end
end

local function notify(title, msg)
    if GetResourceState and GetResourceState('chat') ~= 'missing' then
        TriggerEvent('chat:addMessage', { args = { title or '^2Spikes', msg or '' } })
    else
        BeginTextCommandThefeedPost('STRING')
        AddTextComponentSubstringPlayerName((title or 'Spikes') .. ': ' .. (msg or ''))
        EndTextCommandThefeedPostTicker(false, true)
    end
end

RegisterNetEvent("cprp_spikes:notify")
AddEventHandler("cprp_spikes:notify", function(title, msg)
    notify(title, msg)
end)

-- Authorization round-trip to server when RequireAceUse is enabled.
local function ensureAllowed()
    if not Config.RequireAceUse then return true end
    if allowCache ~= nil then return allowCache end
    if waitingAuth then
        -- avoid spamming during wait
        return false
    end
    waitingAuth = true
    TriggerServerEvent("cprp_spikes:reqAllowed")
    local start = GetGameTimer()
    while allowCache == nil and (GetGameTimer() - start) < 1200 do
        Wait(10)
    end
    waitingAuth = false
    return allowCache == true
end

RegisterNetEvent("cprp_spikes:resAllowed")
AddEventHandler("cprp_spikes:resAllowed", function(ok)
    allowCache = ok and true or false
    if not allowCache then
        notify("^1Spikes", "You are not allowed to deploy or pickup spikes.")
    end
end)

local function modelHash()
    if type(Config.SpikeModel) == 'number' then
        return Config.SpikeModel
    elseif type(Config.SpikeModel) == 'string' then
        return GetHashKey(Config.SpikeModel)
    else
        return GetHashKey('p_ld_stinger_s')
    end
end

local function loadModel(model)
    if not HasModelLoaded(model) then
        RequestModel(model)
        local tries = 0
        while not HasModelLoaded(model) and tries < 200 do
            Wait(10)
            tries = tries + 1
        end
    end
    return HasModelLoaded(model)
end

local function groundZ(x, y, zStart)
    local ok, z = GetGroundZFor_3dCoord(x, y, zStart or 1000.0, false)
    if ok then return z else return zStart or 0.0 end
end

local function ensureControl(ent, timeoutMs)
    local ending = GetGameTimer() + (timeoutMs or 1000)
    NetworkRequestControlOfEntity(ent)
    while not NetworkHasControlOfEntity(ent) and GetGameTimer() < ending do
        NetworkRequestControlOfEntity(ent)
        Wait(10)
    end
    return NetworkHasControlOfEntity(ent)
end

local function spawnSpikeAt(x, y, z, heading)
    local model = modelHash()
    if not loadModel(model) then
        notify("^1Spikes", "Failed to load model " .. tostring(Config.SpikeModel))
        return nil
    end

    z = groundZ(x, y, z + 1.0)
    local ent = CreateObject(model, x, y, z, true, true, false)
    if ent == 0 then
        notify("^1Spikes", "CreateObject failed")
        return nil
    end

    SetEntityHeading(ent, heading + 90.0)
    PlaceObjectOnGroundProperly(ent)
    FreezeEntityPosition(ent, true)
    SetEntityAsMissionEntity(ent, true, false)

    local netId = NetworkGetNetworkIdFromEntity(ent)
    SetNetworkIdExistsOnAllMachines(netId, true)

    table.insert(spawnedSpikes, { ent = ent, net = netId })
    TriggerServerEvent("cprp_spikes:register", netId)
    return ent
end

local function maybeCullOldest()
    local max = Config.MaxActiveSpikesPerPlayer or 6
    if #spawnedSpikes > max then
        local oldest = table.remove(spawnedSpikes, 1)
        if oldest and DoesEntityExist(oldest.ent) then
            if ensureControl(oldest.ent, 500) then
                TriggerServerEvent("cprp_spikes:unregister", NetworkGetNetworkIdFromEntity(oldest.ent))
                DeleteEntity(oldest.ent)
            end
        end
    end
end

local function getRightVectorFromForward(fx, fy)
    return -fy, fx
end

local function spawnN(count)
    if not ensureAllowed() then return end

    local ped = PlayerPedId()
    local px, py, pz = table.unpack(GetEntityCoords(ped))
    local heading = GetEntityHeading(ped)

    local fx, fy, fz = table.unpack(GetEntityForwardVector(ped))
    local rx, ry = getRightVectorFromForward(fx, fy)

    local offset = Config.ForwardOffset or 2.5
    local spacing = Config.SideSpacing or 3.5

    local baseX = px + fx * offset
    local baseY = py + fy * offset
    local baseZ = pz

    local positions = {}

    if count == 1 then
        positions = { {baseX, baseY, baseZ} }
    elseif count == 2 then
        local dx = rx * (spacing * 0.5)
        local dy = ry * (spacing * 0.5)
        positions = { {baseX + dx, baseY + dy, baseZ}, {baseX - dx, baseY - dy, baseZ} }
    else
        local dx = rx * spacing
        local dy = ry * spacing
        positions = { {baseX, baseY, baseZ}, {baseX + dx, baseY + dy, baseZ}, {baseX - dx, baseY - dy, baseZ} }
    end

    for _, p in ipairs(positions) do
        local ent = spawnSpikeAt(p[1], p[2], p[3], heading)
        if ent then
            dbg("Spawned spike " .. tostring(ent))
            maybeCullOldest()
        end
    end
end

local function dist(aX, aY, aZ, bX, bY, bZ)
    return GetDistanceBetweenCoords(aX, aY, aZ, bX, bY, bZ, true)
end

local function pickupNearest()
    if not ensureAllowed() then return end

    local ped = PlayerPedId()
    local px, py, pz = table.unpack(GetEntityCoords(ped))

    local bestIdx = nil
    local bestDist = 1e9

    for i, data in ipairs(spawnedSpikes) do
        if data.ent and DoesEntityExist(data.ent) then
            local sx, sy, sz = table.unpack(GetEntityCoords(data.ent))
            local d = dist(px, py, pz, sx, sy, sz)
            if d < bestDist then
                bestDist = d
                bestIdx = i
            end
        end
    end

    if bestIdx and bestDist < 3.0 then
        local data = table.remove(spawnedSpikes, bestIdx)
        if data and DoesEntityExist(data.ent) then
            if ensureControl(data.ent, 700) then
                TriggerServerEvent("cprp_spikes:unregister", NetworkGetNetworkIdFromEntity(data.ent))
                DeleteEntity(data.ent)
                notify("^2Spikes", "Picked up nearest spike.")
            end
        end
    else
        notify("^2Spikes", "No spike close enough to pick up.")
    end
end

-- Tire pop loop
CreateThread(function()
    while true do
        Wait(Config.VehicleScanIntervalMs or 150)
        if #spawnedSpikes == 0 then
            -- nothing to do
        else
            local spikePos = {}
            for _, data in ipairs(spawnedSpikes) do
                if data.ent and DoesEntityExist(data.ent) then
                    local sx, sy, sz = table.unpack(GetEntityCoords(data.ent))
                    table.insert(spikePos, {sx, sy, sz})
                end
            end

            if #spikePos > 0 then
                local vehicles = GetGamePool('CVehicle')
                for _, veh in ipairs(vehicles) do
                    if DoesEntityExist(veh) and not IsEntityDead(veh) then
                        local vx, vy, vz = table.unpack(GetEntityCoords(veh))
                        local speed = GetEntitySpeed(veh)
                        if speed > (Config.MinSpeedToPop or 4.5) then
                            for _, sp in ipairs(spikePos) do
                                local d = dist(vx, vy, vz, sp[1], sp[2], sp[3])
                                if d <= (Config.VehicleAffectRadius or 6.0) then
                                    local last = spikedRecently[veh] or 0
                                    if GetGameTimer() - last > (Config.RehitCooldownMs or 5000) then
                                        for i = 0, 7 do
                                            if not IsVehicleTyreBurst(veh, i, false) then
                                                SetVehicleTyreBurst(veh, i, true, 1000.0)
                                            end
                                        end
                                        spikedRecently[veh] = GetGameTimer()
                                        break
                                    end
                                end
                            end
                        end
                    end
                end
            end
        end
    end
end)

-- Commands
RegisterCommand('spikes_one', function() spawnN(1) end, false)
RegisterCommand('spikes_two', function() spawnN(2) end, false)
RegisterCommand('spikes_three', function() spawnN(3) end, false)
RegisterCommand('spikes_pickup', function() pickupNearest() end, false)

-- Key mappings
RegisterKeyMapping('spikes_one',   'Deploy 1 spike strip', 'keyboard', Config.KeyDefaults and Config.KeyDefaults.spawn1 or 'F6')
RegisterKeyMapping('spikes_two',   'Deploy 2 spike strips', 'keyboard', Config.KeyDefaults and Config.KeyDefaults.spawn2 or 'F7')
RegisterKeyMapping('spikes_three', 'Deploy 3 spike strips', 'keyboard', Config.KeyDefaults and Config.KeyDefaults.spawn3 or 'F8')
RegisterKeyMapping('spikes_pickup','Pick up nearest spike strip', 'keyboard', Config.KeyDefaults and Config.KeyDefaults.pickup or 'F9')

-- Slash aliases
RegisterCommand('spike1', function() ExecuteCommand('spikes_one') end, false)
RegisterCommand('spike2', function() ExecuteCommand('spikes_two') end, false)
RegisterCommand('spike3', function() ExecuteCommand('spikes_three') end, false)
RegisterCommand('spikepickup', function() ExecuteCommand('spikes_pickup') end, false)

-- Cleanup on resource stop (client)
AddEventHandler('onClientResourceStop', function(res)
    if res ~= GetCurrentResourceName() then return end
    for _, data in ipairs(spawnedSpikes) do
        if data.ent and DoesEntityExist(data.ent) then
            if ensureControl(data.ent, 300) then
                TriggerServerEvent("cprp_spikes:unregister", NetworkGetNetworkIdFromEntity(data.ent))
                DeleteEntity(data.ent)
            end
        end
    end
end)
