fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'cprp_spikes'
author 'Nomad + ChatGPT'
description 'Standalone spike strip deployer (1/2/3), pickup, keybindable. Server clearall, ACE gating, auto-cleanup.'
version '1.1.0'

client_scripts {
    'config.lua',
    'client/main.lua'
}

server_scripts {
    'config.lua',
    'server/main.lua'
}
